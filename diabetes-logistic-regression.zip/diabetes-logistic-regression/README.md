# Diabetes Prediction using Logistic Regression

Streamlit app created from the Jupyter Notebook `ass_8_Logistic Regression.ipynb`.

## Files

- `app.py` - Streamlit application
- `diabetes.csv` - dataset required by the application
- `requirements.txt` - Python dependencies
- `ass_8_Logistic Regression.ipynb` - original notebook

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy

Push the project to GitHub and deploy `app.py` using Streamlit Community Cloud.
