import streamlit as st
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)

st.set_page_config(
    page_title="Diabetes Prediction",
    page_icon="🩺",
    layout="wide",
)

st.title("🩺 Diabetes Prediction using Logistic Regression")
st.write(
    "This Streamlit app is based on the Logistic Regression workflow "
    "from the Jupyter Notebook."
)

# Load dataset
try:
    df = pd.read_csv("diabetes.csv")
except FileNotFoundError:
    st.error(
        "diabetes.csv was not found. Please place diabetes.csv in the same "
        "folder as app.py before running or deploying the app."
    )
    st.stop()

# Same cleaning approach used in the notebook:
# zero values in these medical measurements are treated as missing.
df_clean = df.copy()
cols_with_zero_as_missing = [
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
]
df_clean[cols_with_zero_as_missing] = df_clean[
    cols_with_zero_as_missing
].replace(0, np.nan)

# Train/test split: same settings as notebook
X = df_clean.drop("Outcome", axis=1)
y = df_clean["Outcome"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y,
)

# Same pipeline as notebook
pipeline = Pipeline(
    [
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("model", LogisticRegression(random_state=42)),
    ]
)

pipeline.fit(X_train, y_train)

y_pred = pipeline.predict(X_test)
y_prob = pipeline.predict_proba(X_test)[:, 1]

# Metrics
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_prob)

# Sidebar
st.sidebar.header("Project Information")
st.sidebar.write(f"Dataset rows: {len(df):,}")
st.sidebar.write(f"Features: {X.shape[1]}")
st.sidebar.write("Model: Logistic Regression")
st.sidebar.write("Test size: 20%")
st.sidebar.write("Random state: 42")

# Tabs
tab1, tab2, tab3 = st.tabs(["🔮 Prediction", "📊 Dataset", "📈 Model Performance"])

with tab1:
    st.subheader("Enter Patient Details")

    col1, col2 = st.columns(2)

    with col1:
        pregnancies = st.number_input(
            "Pregnancies",
            min_value=0,
            max_value=20,
            value=1,
            step=1,
        )
        glucose = st.number_input(
            "Glucose",
            min_value=0.0,
            max_value=300.0,
            value=120.0,
            step=1.0,
        )
        blood_pressure = st.number_input(
            "Blood Pressure",
            min_value=0.0,
            max_value=200.0,
            value=70.0,
            step=1.0,
        )
        skin_thickness = st.number_input(
            "Skin Thickness",
            min_value=0.0,
            max_value=150.0,
            value=20.0,
            step=1.0,
        )

    with col2:
        insulin = st.number_input(
            "Insulin",
            min_value=0.0,
            max_value=1000.0,
            value=80.0,
            step=1.0,
        )
        bmi = st.number_input(
            "BMI",
            min_value=0.0,
            max_value=80.0,
            value=32.0,
            step=0.1,
        )
        diabetes_pedigree = st.number_input(
            "Diabetes Pedigree Function",
            min_value=0.0,
            max_value=3.0,
            value=0.47,
            step=0.01,
        )
        age = st.number_input(
            "Age",
            min_value=1,
            max_value=120,
            value=30,
            step=1,
        )

    if st.button("🔍 Predict Diabetes", use_container_width=True):
        input_data = pd.DataFrame(
            {
                "Pregnancies": [pregnancies],
                "Glucose": [glucose],
                "BloodPressure": [blood_pressure],
                "SkinThickness": [skin_thickness],
                "Insulin": [insulin],
                "BMI": [bmi],
                "DiabetesPedigreeFunction": [diabetes_pedigree],
                "Age": [age],
            }
        )

        prediction = pipeline.predict(input_data)[0]
        probability = pipeline.predict_proba(input_data)[0, 1]

        st.divider()

        if prediction == 1:
            st.error("Prediction: Diabetes")
        else:
            st.success("Prediction: No Diabetes")

        st.metric("Predicted Probability of Diabetes", f"{probability:.2%}")
        st.caption(
            "This is a machine-learning demonstration and is not a medical diagnosis."
        )

with tab2:
    st.subheader("Dataset Preview")
    st.dataframe(df.head(10), use_container_width=True)

    c1, c2, c3 = st.columns(3)
    c1.metric("Rows", df.shape[0])
    c2.metric("Columns", df.shape[1])
    c3.metric("Duplicate Rows", int(df.duplicated().sum()))

    st.subheader("Target Distribution")
    st.bar_chart(df["Outcome"].value_counts().sort_index())

with tab3:
    st.subheader("Logistic Regression Performance")

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Accuracy", f"{accuracy:.2%}")
    c2.metric("Precision", f"{precision:.2%}")
    c3.metric("Recall", f"{recall:.2%}")
    c4.metric("F1-Score", f"{f1:.2%}")
    c5.metric("ROC-AUC", f"{roc_auc:.2%}")

    results = pd.DataFrame(
        {
            "Metric": ["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"],
            "Score": [accuracy, precision, recall, f1, roc_auc],
        }
    )
    st.dataframe(results, hide_index=True, use_container_width=True)

st.divider()
st.caption("Logistic Regression • Diabetes Prediction")
